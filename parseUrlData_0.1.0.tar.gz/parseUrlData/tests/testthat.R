library(testthat)
library(parseUrlData)

test_check("parseUrlData")
